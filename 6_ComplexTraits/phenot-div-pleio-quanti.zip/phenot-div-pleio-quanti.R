
# load data    ####
setwd("/path/to/directory/6_ComplexTraitsy")

data <- read.table("pleio-quanti/P2-N1000-D5-m001-cor0.0.txt", header=T)


par(mfrow=c(2,2))
par(mar=c(4.1,4.1,2.1,0.1))

# plot avg. T1  ----
plot(x=data$generation, y=data$adlt.q1.p1, lwd=2, col="transparent", xlab="time", ylab="phenotype, z", main="trait value, T1", las=1, ylim=c(-2,7), type="l")
grid()
lines(x=data$generation, y=data$adlt.q1.p1, lwd=2, col="skyblue")
lines(x=data$generation, y=data$adlt.q1.p2, lwd=2, col="coral")
legend("topleft", y=13, legend=c("patch 1", "patch 2"), lty=1, col=c("skyblue", "coral"), lwd=2, bty="n")

# plot avg. T2  ----
plot(x=data$generation, y=data$adlt.q2.p1, lwd=2, col="transparent", xlab="time", ylab="phenotype, z", main="trait value, T2", las=1, ylim=c(-1,1), type="l")
grid()
lines(x=data$generation, y=data$adlt.q2.p1, lwd=2, col="skyblue")
lines(x=data$generation, y=data$adlt.q2.p2, lwd=2, col="coral")
#legend("topleft", y=13, legend=c("patch 1", "patch 2"), lty=1, col=c("skyblue", "coral"), lwd=2, bty="n")


data <- read.table("pleio-quanti/P2-N1000-D5-m050-cor0.9.txt", header=T)

# plot avg. T1  ----
plot(x=data$generation, y=data$adlt.q1.p1, lwd=2, col="transparent", xlab="time", ylab="phenotype, z", main="trait value, T1", las=1, ylim=c(-2,7), type="l")
grid()
lines(x=data$generation, y=data$adlt.q1.p1, lwd=2, col="skyblue")
lines(x=data$generation, y=data$adlt.q1.p2, lwd=2, col="coral")
legend("topleft", y=13, legend=c("patch 1", "patch 2"), lty=1, col=c("skyblue", "coral"), lwd=2, bty="n")

# plot avg. T2  ----
plot(x=data$generation, y=data$adlt.q2.p1, lwd=2, col="transparent", xlab="time", ylab="phenotype, z", main="trait value, T2", las=1, ylim=c(-1,1), type="l")
grid()
lines(x=data$generation, y=data$adlt.q2.p1, lwd=2, col="skyblue")
lines(x=data$generation, y=data$adlt.q2.p2, lwd=2, col="coral")
#legend("topleft", y=13, legend=c("patch 1", "patch 2"), lty=1, col=c("skyblue", "coral"), lwd=2, bty="n")


par(mfrow=c(1,1))

migr=c(0.001,0.05, 0.25)
cor=c("0.0","0.5","0.9")
filename="pleio-quanti/P2-N1000-D5-m"

t1.p1 = array(NA,dim=c(length(migr), length(cor)))
t1.p2 = array(NA,dim=c(length(migr), length(cor)))
t2.p1 = array(NA,dim=c(length(migr), length(cor)))
t2.p2 = array(NA,dim=c(length(migr), length(cor)))

for(m in 1:length(migr)) {
  for(c in 1:length(cor)) {
    
    d = read.table(paste0(filename, sprintf("%03i",migr[m]*1000),"-cor",cor[c],".txt"), header = TRUE)
    
    t1.p1[m,c] = d$adlt.q1.p1[d$generation==10000]
    t1.p2[m,c] = d$adlt.q1.p2[d$generation==10000]
    t2.p1[m,c] = d$adlt.q2.p1[d$generation==10000]
    t2.p2[m,c] = d$adlt.q2.p2[d$generation==10000]
  }
}

par(mfrow=c(1,2))

plot(migr, t1.p2[,1]-t1.p1[,1],type="o",lwd=2,xlab="dispersal", ylab="divergence",main="Trait 1",ylim=c(0,5))
lines(migr, t1.p2[,2]-t1.p1[,2],type="o",lwd=2,col="dodgerblue",pch=3)
lines(migr, t1.p2[,3]-t1.p1[,3],type="o",lwd=2,col="coral",pch=5)


plot(migr, t2.p2[,1]-t2.p1[,1],type="o",lwd=2,xlab="dispersal", ylab="divergence",main="Trait 2",ylim=c(-1,1))
lines(migr, t2.p2[,2]-t2.p1[,2],type="o",lwd=2,col="dodgerblue",pch=3)
lines(migr, t2.p2[,3]-t2.p1[,3],type="o",lwd=2,col="coral",pch=5)
legend("topright",c("cor=0.0","cor=0.5","cor=0.9"),col=c("black","dodgerblue","coral"),lwd=2, pch=c(1,3,5), bty="n")
